package com.frankmoley.boot.clr.roomclrapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomClrAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomClrAppApplication.class, args);
	}
}
